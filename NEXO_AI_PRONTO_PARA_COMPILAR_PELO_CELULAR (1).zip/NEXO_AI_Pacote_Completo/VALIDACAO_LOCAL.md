# Validação realizada nesta entrega

Data: 12/11/2026

## Verificações executadas

- XML do AndroidManifest.xml: analisado com parser XML.
- package.json: analisado como JSON válido.
- Backend/server.js: verificado com `node --check`.
- Arquivos Kotlin: revisão estática do código e das chamadas principais; não houve compilação Android.
- Pacote ZIP: integridade verificada com `unzip -t`.

## Melhorias desta revisão

- Versão Android atualizada para 1.1.0 (versionCode 2).
- Comandos de lanterna passam a respeitar “ligar” e “desligar”, além de alternar quando o usuário só diz “lanterna”.
- Comandos de volume: aumentar, diminuir, silenciar e ativar som.
- Atalhos para configurações de notificações, localização/GPS, privacidade e aplicativos instalados.
- Comandos locais também recebem resposta falada.
- O app solicita permissão de notificações no Android 13 ou superior.
- Gerenciamento de Text-to-Speech encerrado ao sair da tela.

## O que ainda depende do ambiente do usuário

- Gradle Sync e compilação do APK: requer Android Studio/Gradle e Android SDK Platform 35.
- Instalação e teste real: requer aparelho Android conectado ou instalação manual.
- Palavra “Charles”: continua experimental com SpeechRecognizer; não é hotword offline dedicada e não garante escuta permanente.
- IA conversacional: exige publicar o Backend, configurar `OPENAI_API_KEY` como segredo no servidor e informar a URL HTTPS em `ApiConfig.kt`.
- Permissões de microfone, notificações, câmera e sobreposição devem ser concedidas no próprio Android.
