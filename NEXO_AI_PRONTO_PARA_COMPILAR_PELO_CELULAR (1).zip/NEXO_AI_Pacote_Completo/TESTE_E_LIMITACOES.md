# NEXO AI — checklist de compilação e teste

## Estado desta entrega

- [x] Código Android organizado em projeto Gradle.
- [x] Chat com API HTTPS configurável.
- [x] Resposta por Text-to-Speech.
- [x] Reconhecimento de fala sob ação do usuário.
- [x] Serviço experimental para palavra “Charles”.
- [x] Bolha flutuante com permissão de sobreposição.
- [x] Comandos locais ampliados (incluindo volume, notificações e localização).
- [x] Resposta falada para comandos locais.
- [x] Solicitação de permissão de notificações em Android 13+.
- [x] Backend Node.js com validação básica, Helmet e rate limit.
- [ ] Gradle Sync executado em Android Studio.
- [ ] APK debug compilado.
- [ ] Instalação e teste em aparelho Android físico.
- [ ] Backend publicado e conectado a uma chave válida.
- [ ] Teste de consumo de bateria e estabilidade em segundo plano.

Os itens não marcados dependem de Android Studio/SDK, aparelho físico, permissões e configuração de hospedagem. Não declarar esses testes como concluídos antes de executá-los.

## Matriz mínima de testes

| Teste | Resultado esperado |
|---|---|
| Abrir o app | Tela inicial NEXO aparece |
| Microfone no chat | Reconhecimento transforma fala em texto |
| “Abrir WhatsApp” | Abre WhatsApp se instalado |
| “Abrir Wi-Fi” | Abre ajustes de Wi-Fi |
| “Ligar lanterna” / “desligar lanterna” | Solicita câmera na primeira vez; respeita a ação pedida após autorização |
| “Aumentar volume” / “silenciar” | Ajusta volume de mídia pelo Android |
| “Abrir notificações” | Abre as configurações de notificações do NEXO |
| “Ligar 63999999999” | Abre discador com número preenchido, sem chamar |
| Ativar Charles | Notificação informa que microfone está em uso |
| “Charles, abrir configurações” | Abre o NEXO e tenta executar o comando local |
| Parar voz | Serviço de escuta é encerrado |
| Ativar bolinha | Solicita sobreposição e mostra bolha |
| Chat com backend | Retorna resposta quando URL e chave do servidor estão configuradas |

## Limitações conhecidas

1. `SpeechRecognizer` não é um mecanismo profissional de hotword. A escuta reiniciada em sessões curtas pode falhar ou ser interrompida pelo Android; não garante ativação permanente.
2. Alguns comandos dependem de apps instalados e intents implementados pelo fabricante.
3. O comando de chamada abre somente o discador. Não inicia chamada automaticamente.
4. A bolha é um atalho para abrir a tela principal, não uma janela de conversa completa.
5. O backend não está publicado por padrão. É necessário configurar segredo, hospedagem e URL.
6. O APK debug não é uma versão pronta para publicação.
