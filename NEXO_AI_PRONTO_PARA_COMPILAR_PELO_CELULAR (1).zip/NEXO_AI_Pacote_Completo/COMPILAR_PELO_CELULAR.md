# Gerar o APK do NEXO usando somente o celular

Este pacote já contém o workflow do GitHub Actions em `.github/workflows/android-apk.yml`. A compilação acontece nos servidores do GitHub; o celular é usado para enviar o projeto e baixar o APK.

## Antes de começar
- Tenha uma conta GitHub (gratuita serve).
- Baixe e extraia o ZIP no celular usando o app Arquivos/Files.
- Não envie chaves de API, senhas ou arquivos `.env` com segredos.

## Enviar o projeto
1. Abra https://github.com no Chrome e entre na sua conta.
2. Crie um repositório novo chamado `nexo-ai`; deixe-o **Private** e não marque para adicionar README, licença ou `.gitignore`.
3. Abra o repositório e use **Add file > Upload files**.
4. Envie o conteúdo de dentro da pasta `NEXO_AI_Pacote_Completo` extraída do ZIP, incluindo a pasta oculta `.github` e o arquivo `COMPILAR_PELO_CELULAR.md`. Se o seletor do celular não mostrar arquivos/pastas ocultos, ative “mostrar arquivos ocultos” no gerenciador de arquivos.
5. Toque em **Commit changes** para salvar.

## Executar a compilação
1. No repositório, abra a aba **Actions**.
2. Se aparecer uma mensagem para habilitar Actions, habilite.
3. Escolha **Build NEXO AI APK** na lista de workflows.
4. Toque em **Run workflow** e confirme em **Run workflow**.
5. Aguarde o trabalho terminar com marca verde. Se ficar vermelho, abra o trabalho e consulte o primeiro erro; não significa que o APK foi criado.
6. Abra a execução concluída e baixe o artefato **NEXO-AI-debug-APK**. O GitHub baixa um ZIP contendo `app-debug.apk`.
7. Extraia o ZIP do artefato e toque em `app-debug.apk` para instalar. Se o Android pedir, permita instalação pelo Chrome/Arquivos e prossiga.

## Observações
- O APK é de depuração e serve para testes; não é uma versão pronta para publicar na Play Store.
- O APK só existe se o workflow terminar com sucesso e o artefato estiver disponível.
- A palavra “Charles” ainda é experimental: o Android pode interromper o microfone, exigir notificação permanente e consumir bateria. Não há garantia de escuta 24 horas.
- A conversa com IA exige publicar o backend e configurar a URL HTTPS em `Android/app/src/main/java/com/nexo/ai/ApiConfig.kt`. Não coloque a chave do provedor de IA dentro do app ou do repositório.
