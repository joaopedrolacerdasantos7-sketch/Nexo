package com.nexo.ai

/**
 * Configure this URL to point to YOUR secure backend.
 * Do not put a provider API secret (OpenAI, Gemini, etc.) in this Android app.
 *
 * Expected contract:
 * POST {BASE_URL}/chat
 * JSON body: {"message":"Hello","conversationId":"optional-id"}
 * JSON response: {"reply":"Hello!","conversationId":"optional-id"}
 */
object ApiConfig {
    const val BASE_URL = "https://YOUR-BACKEND-DOMAIN.example/"
    const val CHAT_PATH = "chat"
}
