package com.nexo.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class NexoApiClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun sendMessage(message: String, conversationId: String? = null): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(!ApiConfig.BASE_URL.contains("YOUR-BACKEND-DOMAIN")) {
                    "Configure a URL real do seu backend em ApiConfig.kt."
                }
                val base = ApiConfig.BASE_URL.trimEnd('/') + "/"
                val payload = JSONObject().put("message", message)
                if (!conversationId.isNullOrBlank()) payload.put("conversationId", conversationId)

                val body = payload.toString()
                    .toRequestBody("application/json; charset=utf-8".toMediaType())

                val request = Request.Builder()
                    .url(base + ApiConfig.CHAT_PATH)
                    .post(body)
                    .header("Accept", "application/json")
                    .build()

                client.newCall(request).execute().use { response ->
                    val responseText = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw IllegalStateException("Servidor respondeu HTTP ${response.code}: ${responseText.take(250)}")
                    }
                    val json = JSONObject(responseText)
                    json.optString("reply").takeIf { it.isNotBlank() }
                        ?: throw IllegalStateException("Resposta da API sem o campo 'reply'.")
                }
            }
        }
}
