package com.nexo.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/** Comandos locais explícitos. Ações sensíveis sempre abrem a tela oficial do Android. */
object VoiceCommandRouter {
    private const val CAMERA_PERMISSION_REQUEST = 79
    @Volatile private var torchOn = false

    fun execute(context: Context, raw: String): String? {
        val command = raw.lowercase().trim()
        if (command.isBlank()) return null

        if (command.contains("lanterna") || command.contains("flashlight")) {
            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (context is Activity) {
                    ActivityCompat.requestPermissions(context, arrayOf(android.Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST)
                    return "Preciso da permissão da câmera para controlar a lanterna. Autorize e repita o comando."
                }
                return "Abra as permissões do NEXO e autorize a câmera para usar a lanterna."
            }
            return runCatching {
                val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val cameraId = manager.cameraIdList.firstOrNull { id ->
                    manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return "Este aparelho não disponibiliza lanterna pela câmera."
                val requestedState = when {
                    command.contains("desligar") || command.contains("apagar") -> false
                    command.contains("ligar") || command.contains("acender") -> true
                    else -> !torchOn
                }
                manager.setTorchMode(cameraId, requestedState)
                torchOn = requestedState
                if (torchOn) "Lanterna ligada." else "Lanterna desligada."
            }.getOrElse { "Não consegui controlar a lanterna neste aparelho. Verifique se outro app está usando a câmera." }
        }

        val appPackages = listOf(
            "whatsapp" to "com.whatsapp",
            "instagram" to "com.instagram.android",
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "navegador" to "com.android.chrome",
            "spotify" to "com.spotify.music",
            "tiktok" to "com.zhiliaoapp.musically",
            "facebook" to "com.facebook.katana",
            "gmail" to "com.google.android.gm",
            "mapas" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps"
        )
        val app = appPackages.firstOrNull { command.contains(it.first) }
        if (app != null) {
            val launch = context.packageManager.getLaunchIntentForPackage(app.second)
                ?: return "Não encontrei esse aplicativo instalado."
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launch)
            return "Abrindo ${app.first}."
        }

        // Volume pode ser ajustado pelo próprio Android sem abrir telas externas.
        if (command.contains("volume") || command.contains("som")) {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            return runCatching {
                when {
                    command.contains("aumentar") || command.contains("mais alto") || command.contains("subir") ->
                        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    command.contains("diminuir") || command.contains("mais baixo") || command.contains("baixar") ->
                        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    command.contains("silenciar") || command.contains("mudo") ->
                        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    command.contains("ativar som") || command.contains("tirar do mudo") ->
                        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                    else -> return "Diga aumentar volume, diminuir volume, silenciar ou ativar som."
                }
                "Ajustei o volume."
            }.getOrElse { "Não consegui ajustar o volume neste aparelho." }
        }

        val intent: Intent = when {
            command.contains("notificações") || command.contains("notificacoes") -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            command.contains("localização") || command.contains("localizacao") || command.contains("gps") -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            command.contains("privacidade") -> Intent(Settings.ACTION_PRIVACY_SETTINGS)
            command.contains("aplicativos") || command.contains("apps instalados") -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            command.contains("configurações") || command.contains("configuracoes") || command == "configurar celular" -> Intent(Settings.ACTION_SETTINGS)
            command.contains("wifi") || command.contains("wi-fi") -> Intent(Settings.ACTION_WIFI_SETTINGS)
            command.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            command.contains("internet") || command.contains("rede") || command.contains("dados móveis") -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
            command.contains("bateria") || command.contains("economia de energia") -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            command.contains("brilho") || command.contains("configuração de tela") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            command.contains("alarme") || command.contains("despertador") -> Intent(AlarmClock.ACTION_SHOW_ALARMS)
            command.contains("câmera") || command.contains("camera") || command.contains("tirar foto") -> Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            command.contains("calculadora") || command.contains("calcular") -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALCULATOR)
            command.contains("contatos") || command.contains("agenda telefônica") -> Intent(Intent.ACTION_VIEW, Uri.parse("content://contacts/people/"))
            command.contains("mapa") || command.contains("navegar") || command.contains("rota") -> {
                val destination = command.substringAfter("para", "").trim()
                if (destination.isNotBlank()) Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(destination)}"))
                else Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q="))
            }
            command.contains("ligar") || command.contains("telefone") || command.contains("chamar") -> {
                val digits = command.filter { it.isDigit() }
                if (digits.isBlank()) return "Diga ‘ligar’ seguido do número. Vou abrir o discador sem iniciar a chamada."
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits"))
            }
            else -> return null
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            context.startActivity(intent)
            "Abrindo a função solicitada."
        }.getOrElse { "Esse comando não é compatível ou não há aplicativo disponível neste aparelho." }
    }
}
