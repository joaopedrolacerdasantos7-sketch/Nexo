package com.nexo.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    companion object { const val EXTRA_WAKE_COMMAND = "nexo_wake_command" }
    private var voiceManager: VoiceRecognitionManager? = null
    private var speechCallback: ((String) -> Unit)? = null
    private var errorCallback: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 80)
        }
        setContent { NexoScreen(
            onStartVoice = { onText, onError ->
                speechCallback = onText
                errorCallback = onError
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    startVoice(onText, onError)
                } else {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
                }
            },
            onStartFloating = { enableFloating() },
            onStartWakeWord = { startWakeWord() },
            onStopWakeWord = { stopService(Intent(this, WakeWordService::class.java)) },
            initialCommand = intent?.getStringExtra(EXTRA_WAKE_COMMAND).orEmpty()
        ) }
    }

    private fun startVoice(onText: (String) -> Unit, onError: (String) -> Unit) {
        voiceManager?.destroy()
        voiceManager = VoiceRecognitionManager(this, onText, onError)
        voiceManager?.startListening()
    }

    private fun startWakeWord() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 78)
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, WakeWordService::class.java))
    }

    private fun enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, FloatingAssistantService::class.java))
    }

    @Deprecated("Use Activity Result APIs in a future update")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            speechCallback?.let { onText -> startVoice(onText) { errorCallback?.invoke(it) } }
        } else if (requestCode == 77) errorCallback?.invoke("Permissão de microfone não concedida.")
        else if (requestCode == 78 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startWakeWord()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    override fun onDestroy() {
        voiceManager?.destroy()
        super.onDestroy()
    }
}

@Composable
private fun NexoScreen(
    onStartVoice: ((String) -> Unit, (String) -> Unit) -> Unit,
    onStartFloating: () -> Unit,
    onStartWakeWord: () -> Unit,
    onStopWakeWord: () -> Unit,
    initialCommand: String
) {
    val context = LocalContext.current
    val api = remember { NexoApiClient() }
    val tts = remember { TextToSpeechManager(context) }
    DisposableEffect(tts) { onDispose { tts.shutdown() } }
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatMessage("Olá! Eu sou o NEXO. Como posso ajudar?", false)) }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty() || loading) return
        val localResult = VoiceCommandRouter.execute(context, clean)
        if (localResult != null) {
            messages.add(ChatMessage(clean, true))
            messages.add(ChatMessage(localResult, false))
            tts.speak(localResult)
            input = ""
            return
        }
        messages.add(ChatMessage(clean, true))
        input = ""
        loading = true
        scope.launch {
            api.sendMessage(clean).onSuccess { reply ->
                messages.add(ChatMessage(reply, false))
                tts.speak(reply)
            }.onFailure { error ->
                messages.add(ChatMessage("Não consegui conectar: ${error.message}", false))
            }
            loading = false
        }
    }

    LaunchedEffect(initialCommand) { if (initialCommand.isNotBlank()) send(initialCommand) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF36C8FF),
            background = Color(0xFF07111F),
            surface = Color(0xFF101F32)
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF07111F), Color(0xFF102B46)))
            ).padding(18.dp)
        ) {
            Text("NEXO", color = Color(0xFF65D9FF), fontSize = 32.sp, fontWeight = FontWeight.Black)
            Text("ASSISTENTE INTELIGENTE", color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStartFloating, modifier = Modifier.weight(1f)) {
                    Text("Ativar bolinha")
                }
                OutlinedButton(onClick = {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                    context.startActivity(intent)
                }, modifier = Modifier.weight(1f)) {
                    Text("Permissões")
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onStartWakeWord, modifier = Modifier.weight(1f)) { Text("Ativar Charles") }
                OutlinedButton(onClick = onStopWakeWord, modifier = Modifier.weight(1f)) { Text("Parar voz") }
            }
            Spacer(Modifier.height(14.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF075985) else Color(0xFF172B42),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, color = Color.White, modifier = Modifier.padding(13.dp))
                        }
                    }
                }
                if (loading) item { Text("NEXO está pensando...", color = Color(0xFF65D9FF)) }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Converse com o NEXO") },
                    maxLines = 3
                )
                IconButton(onClick = {
                    listening = true
                    onStartVoice({ recognized -> listening = false; send(recognized) }, { err ->
                        listening = false
                        messages.add(ChatMessage(err, false))
                    })
                }) {
                    Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, contentDescription = "Falar", tint = Color(0xFF65D9FF))
                }
                IconButton(onClick = { send(input) }, enabled = !loading) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar", tint = Color(0xFF65D9FF))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Diga ‘Charles’ com a ativação ligada. O Android mantém uma notificação enquanto o microfone estiver ativo.", color = Color.LightGray, fontSize = 10.sp)
        }
    }
}
