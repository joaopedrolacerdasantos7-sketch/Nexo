# NEXO AI — projeto Android

Projeto-base Android nativo em Kotlin + Jetpack Compose. O código inclui chat com backend, resposta falada, reconhecimento de fala acionado pelo usuário, serviço de palavra de ativação “Charles” em modo experimental, bolha flutuante e comandos locais.

## Requisitos para compilar

- Android Studio atualizado (recomendado Android Studio com suporte a AGP 8.7.3).
- JDK 17 ou 21.
- Android SDK Platform 35 e Build Tools instalados pelo SDK Manager.
- Internet para baixar plugins e dependências na primeira sincronização.

## Compilar APK de teste

1. Extraia o ZIP.
2. Abra a pasta `Android` no Android Studio (não abra a pasta `app`).
3. Aguarde o Gradle Sync. Se o Android Studio solicitar, instale Android SDK Platform 35.
4. Selecione `Build > Build Bundle(s) / APK(s) > Build APK(s)` ou execute no terminal, dentro de `Android`:

   ```bash
   gradle :app:assembleDebug
   ```

5. O APK de depuração será criado em `Android/app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK para o Android, autorize a instalação para a origem usada e instale.

O APK debug não é assinado para publicação na Play Store. Para distribuição pública, gere uma versão release assinada e revise políticas/permissões.

## Configurar a conversa com IA

Edite `app/src/main/java/com/nexo/ai/ApiConfig.kt` e substitua `BASE_URL` pela URL HTTPS do backend publicado. A chave do provedor de IA fica exclusivamente no servidor, nunca no aplicativo.

O backend está na pasta `../Backend`. Consulte o README de lá para configurar `OPENAI_API_KEY` e publicar. A API só responde quando o backend estiver publicado e a variável de ambiente estiver configurada. Comandos locais continuam funcionando sem backend.

## Primeiro teste no celular

1. Abra o NEXO e permita microfone e notificações quando solicitados.
2. Teste o microfone do chat com uma frase curta.
3. Teste “abrir configurações”, “abrir WhatsApp” e “abrir Wi-Fi”.
4. Para a lanterna, diga “ligar lanterna”; conceda a permissão de câmera e repita. Diga novamente para desligar.
5. Toque em “Ativar Charles”, mantenha o aviso de microfone visível e diga “Charles, abrir configurações”.
6. Para encerrar, toque em “Parar voz” no app ou na notificação persistente.
7. Teste “Ativar bolinha”, autorize “Exibir sobre outros apps” e toque novamente.

## Comandos locais incluídos

- Aplicativos (se instalados): WhatsApp, Instagram, YouTube, Chrome, Spotify, TikTok, Facebook, Gmail e Mapas.
- Configurações: configurações gerais, Wi-Fi, Bluetooth, rede/internet, bateria e tela.
- Ferramentas: lanterna (com permissão), câmera, calculadora, contatos, alarmes e mapas.
- Som: “aumentar volume”, “diminuir volume”, “silenciar” e “ativar som”. O Android pode exibir o controle de volume do sistema.
- Configurações adicionais: notificações do NEXO, localização/GPS, privacidade e lista de aplicativos.
- Telefone: “ligar” + número abre o discador. O NEXO não inicia chamada sem confirmação do usuário.

O Android ou o fabricante pode não disponibilizar algum aplicativo ou intent. Nesses casos o app informa que não conseguiu abrir.

## Ativação “Charles”: limitação importante

A implementação atual é experimental. Ela usa `SpeechRecognizer` do Android em sessões curtas que são reiniciadas, não um detector dedicado offline de palavra-chave. Pode depender de internet/serviço de reconhecimento, consumir bateria, ter falsos reconhecimentos e ser interrompida pelo Android, pelo fabricante ou pela economia de bateria. Não garante escuta 24 horas, funcionamento com tela desligada, após reinicialização nem execução em todos os modelos. O usuário deve iniciar e parar a escuta conscientemente; uma notificação persistente indica o uso do microfone.

## Segurança e privacidade

- O microfone só começa após ação explícita no aplicativo.
- O app não grava nem envia áudio bruto ao backend: o reconhecimento de voz do Android devolve texto; o texto pode ser enviado ao backend quando o usuário conversa com a IA.
- Comandos locais abrem intents oficiais; não tentam contornar permissões nem controlar silenciosamente outros aplicativos.
- O backend tem limite de tamanho e rate limit básico. Proteja a URL, monitore uso e configure limites/custos no provedor e hospedagem.
- Não inclua chaves privadas no APK ou no repositório.
