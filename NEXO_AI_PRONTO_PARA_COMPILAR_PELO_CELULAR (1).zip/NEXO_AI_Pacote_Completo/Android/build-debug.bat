@echo off
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle nao encontrado. Instale Android Studio/Gradle e Android SDK Platform 35.
  exit /b 1
)
gradle :app:assembleDebug
if errorlevel 1 exit /b 1
echo APK: app\build\outputs\apk\debug\app-debug.apk
