import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
app.use(helmet());
app.use(express.json({ limit: "20kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 20 }));

const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("Defina OPENAI_API_KEY nas variáveis de ambiente do servidor.");
}
const openai = apiKey ? new OpenAI({ apiKey }) : null;

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "NEXO AI API" });
});

app.post("/chat", async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: "Backend sem chave de IA configurada." });

    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message || message.length > 4000) {
      return res.status(400).json({ error: "Envie uma mensagem de 1 a 4000 caracteres." });
    }

    const result = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: "Você é o NEXO, um assistente virtual útil, claro e seguro. Responda em português do Brasil. Não afirme que executou ações no aparelho; o aplicativo Android é responsável por ações locais autorizadas.",
      input: message,
      max_output_tokens: 700
    });

    res.json({ reply: result.output_text || "Não consegui formular uma resposta." });
  } catch (error) {
    console.error("Erro em /chat:", error?.message || error);
    res.status(500).json({ error: "Não foi possível processar a mensagem agora." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXO API ouvindo na porta ${port}`));
