# NEXO AI — servidor

Servidor intermediário entre o aplicativo Android e a API de IA. A chave da OpenAI fica no servidor, nunca no APK.

## Publicar no Render

1. Um adulto responsável deve criar/usar uma conta no Render e um repositório Git privado ou público com esta pasta.
2. Envie o conteúdo desta pasta para um repositório Git.
3. No Render, escolha **New > Blueprint** e conecte o repositório.
4. O Render reconhecerá `render.yaml` e criará o serviço `nexo-ai-api`.
5. Na configuração do serviço, preencha `OPENAI_API_KEY` com a chave criada e administrada pelo adulto responsável.
6. Aguarde o deploy. Teste `https://SUA-URL.onrender.com/health`; a resposta esperada é `{"ok":true,"service":"NEXO AI API"}`.

**Atenção:** hospedagem e chamadas à API podem gerar custos. Confira os preços e limites antes de ativar. Não coloque a chave em arquivos do app, Git, prints ou conversas.

## Executar localmente

Requer Node.js 20 ou superior:

```bash
npm install
OPENAI_API_KEY="sua-chave-no-ambiente-local" npm start
```

No Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="sua-chave-no-ambiente-local"
npm start
```

Teste `GET /health` e depois `POST /chat` com JSON `{"message":"Olá"}`.

## Ligar ao Android

No Android Studio, abra `app/src/main/java/com/nexo/ai/ApiConfig.kt` e troque `BASE_URL` pela URL HTTPS real do serviço, mantendo a barra final. Exemplo ilustrativo: `https://nexo-ai-api.onrender.com/`.

## Limitações atuais

Este é um protótipo funcional de backend, não um serviço pronto para lançamento público. Antes de oferecer a outras pessoas, implemente autenticação real por usuário, limites de uso por conta, proteção contra abuso, política de privacidade, termos, monitoramento e controle de custos. O limite de requisições por IP existente é apenas uma proteção básica.
